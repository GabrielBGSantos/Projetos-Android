package com.example.agenda;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

public class TelaConsulta extends AppCompatActivity {
    Button btn_fechar;
    ListView lv_consulta;
    SQLiteDatabase db = null;
    Cursor cursor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_consulta);

        lv_consulta = (ListView) findViewById(R.id.lv_consulta);
        btn_fechar=(Button) findViewById(R.id.btn_fechar_consulta);

        cursor = BancoDados.buscarTodosDados(this);
        if(cursor.getCount()!=0){
            cursor.moveToFirst();
            listarDados();
        }else{
            CxMsg.mostrar("Nenhum registro encontrado",this);
        }
    }
    public void listarDados() {
        try {
            BancoDados.abrirBanco(this);
            Cursor cursor = BancoDados.buscarTodosDados(this);
            ArrayList<String> linhas = new ArrayList<String>();
            ArrayAdapter adapter = new ArrayAdapter<String>(
                    this,
                    android.R.layout.simple_list_item_1,
                    android.R.id.text1,
                    linhas
            );
            lv_consulta.setAdapter(adapter);
            cursor.moveToFirst();
            while(cursor != null){
                linhas.add(cursor.getString(0));
                cursor.moveToNext();
            }
        }catch (Exception ex){
            if(cursor.isBeforeFirst()){
                CxMsg.mostrar("Não existem mais registros",this);
            }
        }

    }
    public void fechar_tela(View v){
        this.finish();
    }
}