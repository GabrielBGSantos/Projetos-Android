package com.example.agenda;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    EditText et_nome,et_telefone,et_cpf,et_cep;
    Button btn_gravar,btn_consultar,btn_fechar;

    static Cursor cursor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        et_nome=(EditText) findViewById(R.id.et_nome);
        et_telefone=(EditText) findViewById(R.id.et_telefone);
        et_cpf=(EditText) findViewById(R.id.et_cpf_consulta);
        et_cep=(EditText) findViewById(R.id.et_cep_consulta);
        btn_gravar=(Button) findViewById(R.id.btn_gravar);
        btn_consultar=(Button) findViewById(R.id.btn_consultar);
        btn_fechar=(Button) findViewById(R.id.btn_fechar);

        BancoDados.abrirBanco(this);
        BancoDados.abrirOuCriarTabela(this);
        BancoDados.fecharDB();
    }

    public void inserirRegistro(View v){
        String st_nome, st_fone, st_cpf, st_cep;
        st_nome = et_nome.getText().toString();
        st_fone = et_telefone.getText().toString();
        st_cpf = et_cpf.getText().toString();
        st_cep = et_cep.getText().toString();
        if(st_nome == "" || st_fone== "" || st_cpf == "" || st_cep==""){
            CxMsg.mostrar("Esses campos nao podem estar vazios",this);
            return;
        }
        BancoDados.inserirRegistro(st_nome,st_fone,st_cpf,st_cep,this);
        et_nome.setText(null);
        et_telefone.setText(null);
        et_cpf.setText(null);
        et_cep.setText(null);
    }

    public void abrir_tela_consulta(View v){
        BancoDados.abrirBanco(this);
        Intent it_tela_consulta=new Intent(this,TelaConsulta.class);
        startActivity(it_tela_consulta);
    }



    public void fechar_tela(View v){
        this.finish();
    }

}