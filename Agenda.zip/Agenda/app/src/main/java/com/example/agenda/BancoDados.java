package com.example.agenda;
import static android.content.Context.MODE_PRIVATE;

import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.content.ContextWrapper;
import android.view.View;

public class BancoDados {
    static SQLiteDatabase db=null;
    static Cursor cursor;
    public static void abrirBanco(Activity act){
        try {
            ContextWrapper cw=new ContextWrapper(act);
            db=cw.openOrCreateDatabase("bancoAgenda",MODE_PRIVATE,null);
        }catch (Exception ex){
            CxMsg.mostrar("Erro ao abrir ou criar banco de dados",act);
        }
    }
    public static void abrirOuCriarTabela(Activity act) {
        try {
            db.execSQL("CREATE TABLE IF NOT EXISTS contatos (id INTEGER PRIMARY KEY, nome TEXT, fone TEXT, cpf TEXT, cep TEXT);");
        } catch (Exception ex) {
            CxMsg.mostrar("Erro ao criar tabela",act);
        }
    }

    public static void inserirRegistro(String nome, String fone, String cpf, String cep, Activity act){
        abrirBanco(act);
        try {
            db.execSQL("INSERT INTO contatos (nome,fone,cpf,cep) VALUES ('"+nome+"','"+fone+"','"+cpf+"','"+cep+"')");
        }catch (Exception ex){
            CxMsg.mostrar("Erro ao inserir registro",act);
        }finally {
            CxMsg.mostrar("Registro inserido com sucesso",act);
        }
        fecharDB();

    }

    public static Cursor buscarTodosDados(Activity act){
        abrirBanco(act);
        cursor=db.query("contatos",new String[]{"nome","fone","cpf","cep"},null,null,null,null,null,null);
        return cursor;
    }

    public static void fecharDB(){
        db.close();
    }
}
